#!/bin/bash

sudo python3 server.py

