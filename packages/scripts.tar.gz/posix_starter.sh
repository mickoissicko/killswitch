#!/bin/bash

main()
{
    sudo python3 server.py
}

main()

